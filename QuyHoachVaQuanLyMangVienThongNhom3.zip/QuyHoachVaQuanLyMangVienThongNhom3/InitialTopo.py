# Thư viện
import random
import math
import matplotlib.pyplot as plt
import Node

def sortListPosition(m):
    return m.get_position_x()

def Global_Init_Topo(SPC,NumNode,DeBug):
    '''

    Bước 1: Dựng Topology mạng và tính toán lưu lượng tại từng nút mạng

    '''
    print("{:*<100}".format(''))
    print("Bước 1: Dựng Topology mạng và tính toán lưu lượng tại từng nút mạng")
    print("{:*<100}".format(''))
    ListPosition = []


    # Tạo các nút ở vị trí random và đưa vào danh sách, sắp xếp các nút theo thứ tự tọa độ x tăng dần
    for i in range(NumNode):
        n = Node.Node()
        n.create_position(SPC)
        n.create_name(i + 1)
        ListPosition.append(n)
      #  ListPosition.sort(key=sortListPosition)

    # Cài đặt lại vị trí các nút theo đề bài
    # Nút 1 -> ListPosition[0]

    # Tạo ma trận lưu trữ thông tin về lưu lượng giữa các nút.

    TrafficMatrix = [[0] * NumNode for i in range(NumNode)]

    # for i in TrafficMatrix:
    #     for j in i:
    #         print(j,end=' ')
    #     print()

    # Đưa thông tin lưu lượng vào ma trận

    # Đưa thông tin bằng điểm cố định

    def set_traffic(m, n, value):
        TrafficMatrix[m - 1][n - 1] = value
        TrafficMatrix[n - 1][m - 1] = value

    # Đưa thông tin về mối quan hệ
    def set_traffic0(m, n, value):
        TrafficMatrix[m][n] = value
        TrafficMatrix[n][m] = value

    for i in range(NumNode):

        if i + 14 < NumNode:
            set_traffic0(i, i + 14, 1)
        if i + 91 < NumNode:
            set_traffic0(i, i + 91, 3)
        if i + 55 < NumNode:
            set_traffic0(i, i + 55, 2)

    set_traffic(10, 18, 38)
    set_traffic(14, 37, 36)
    set_traffic(18, 32, 3 )
    set_traffic(48, 62, 4 )
    set_traffic(48, 66, 5 )

    # for i in TrafficMatrix:
    #     for j in i:
    #         print(j,end=' ')
    #     print()

    # Sau khi có ma trận lưu lượng, Tiến hành tính lưu lượng của mỗi nút và cập nhật vào nút

    for i in range(len(ListPosition)):
        ListPosition[i].set_traffic(sum(TrafficMatrix[ListPosition[i].get_name() - 1]))
        # ListPosition[i].print()

    # Cập nhật giá EsauWilliam của các nút

    for i in ListPosition:
            i.set_weight_ew(1)

    if DeBug:

        print("---------Topology mạng-------------")
        Node.printInitialList(ListPosition)

        print("----------Kết thúc tạo topology-------------")

    Node.matplotList(ListPosition, SPC)
    Node.plt.show()
    return ListPosition

def Global_Init_Topo_Fix_Position(SPC,NumNode,DeBug):
    '''

    Bước 1: Dựng Topology mạng và tính toán lưu lượng tại từng nút mạng

    '''
    print("{:*<100}".format(''))
    print("Bước 1: Dựng Topology mạng và tính toán lưu lượng tại từng nút mạng")
    print("{:*<100}".format(''))
    ListPosition = []

    ListXY = []

    for i in range(NumNode):
        ListXY.append([(i%10)*0.1*SPC,(i//10)*0.1*SPC])


    # Tạo các nút ở vị trí xác định và đưa vào danh sách, sắp xếp các nút theo thứ tự tọa độ x tăng dần
    for i in range(NumNode):
        n = Node.Node()
        n.set_position(ListXY[i][0],ListXY[i][1])
        n.create_name(i + 1)
        ListPosition.append(n)
      #  ListPosition.sort(key=sortListPosition)

    # Cài đặt lại vị trí các nút theo đề bài
    # Nút 1 -> ListPosition[0]

    # Tạo ma trận lưu trữ thông tin về lưu lượng giữa các nút.

    TrafficMatrix = [[0] * NumNode for i in range(NumNode)]

    # for i in TrafficMatrix:
    #     for j in i:
    #         print(j,end=' ')
    #     print()

    # Đưa thông tin lưu lượng vào ma trận

    # Đưa thông tin bằng điểm cố định

    def set_traffic(m, n, value):
        TrafficMatrix[m - 1][n - 1] = value
        TrafficMatrix[n - 1][m - 1] = value

    # Đưa thông tin về mối quan hệ
    def set_traffic0(m, n, value):
        TrafficMatrix[m][n] = value
        TrafficMatrix[n][m] = value

###


###    Cấu hình mạng


###

    for i in range(NumNode):
        if i + 14 < NumNode:
            set_traffic0(i, i + 14, 1)
        if i + 91 < NumNode:
            set_traffic0(i, i + 91, 3)
        if i + 55 < NumNode:
            set_traffic0(i, i + 55, 2)

    set_traffic(10, 18, 38)
    set_traffic(14, 37, 36)
    set_traffic(18, 32, 3 )
    set_traffic(48, 66, 5 )
    set_traffic(48, 62, 4 )

###

###    Kết Thúc Cấu hình mạng

###

    # Sau khi có ma trận lưu lượng, Tiến hành tính lưu lượng của mỗi nút và cập nhật vào nút

    for i in range(len(ListPosition)):
        ListPosition[i].set_traffic(sum(TrafficMatrix[ListPosition[i].get_name() - 1]))
        # ListPosition[i].print()

    # Cập nhật giá EsauWilliam của các nút

    for i in ListPosition:
            i.set_weight_ew(1)

    if DeBug:

        print("---------Topology mạng-------------")
        Node.printInitialList(ListPosition)

        print("----------Kết thúc tạo topology-------------")
    Node.matplotList(ListPosition, MAX)
    Node.plt.show()
    return ListPosition