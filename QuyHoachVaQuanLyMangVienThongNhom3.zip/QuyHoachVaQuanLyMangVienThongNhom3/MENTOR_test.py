import networkx as nx
import matplotlib.pyplot as plt
import random
import Node
import math

# Tạo đồ thị
G = nx.Graph()

# Thêm nút và cạnh với trọng số
for i in range(1, 101):
    G.add_node(i)

for i in range(1, 87):
    G.add_edge(i, i + 14, weight=1)

for i in range(1, 10):
    G.add_edge(i, i + 91, weight=3)

for i in range(1, 45):
    G.add_edge(i, i + 55, weight=2)

for i in range(1, 60):
    G.add_edge(i, i + 41, weight=1)

for i in range(1, 45):
    G.add_edge(i, i + 56, weight=1)

G.add_edge(10, 18, weight=38)
G.add_edge(37, 14, weight=36)
G.add_edge(48, 62, weight=4)
G.add_edge(48, 66, weight=5)
G.add_edge(18, 32, weight=3)

# Tìm cây truy nhập có trọng số nhỏ nhất (MST)
mst_edges = list(nx.minimum_spanning_edges(G, algorithm='kruskal', data=True))

# Hiển thị kết quả
pos = nx.random_layout(G)
nx.draw_networkx_nodes(G, pos, node_size=100)
nx.draw_networkx_edges(G, pos, edgelist=mst_edges, width=1, edge_color='g')
nx.draw_networkx_labels(G, pos, font_size=8)


plt.title('Minimum Spanning Tree (Kruskal)')
plt.grid()
plt.show()