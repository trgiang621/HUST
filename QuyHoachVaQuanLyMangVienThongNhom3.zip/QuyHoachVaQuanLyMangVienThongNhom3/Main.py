import Node
import InitialTopo
import MENTOR
import EsauWilliam


SPC = 1000 # SPC là thông số độ dài cạnh của mặt phẳng hình vuông kích thước SPC*SPC, nơi các nút được thiết lập lên.
NumNode = 100 # Số lượng nút trong mạng
R = 0.3 # radius ratio - Tỉ lệ dùng để tính bán kính quét mạng truy nhập của thuật toán MENTOR
C = 20 # Dung lượng liên kết
W = 2  # Trọng số lưu lượng chuẩn hóa dùng để xét nút backbone của thuật toán MENTOR
W_EsWi = 20 # Trọng số ngưỡng của các nhóm trong cây truy nhập của thuật toán Esau Williams

ListPosition = InitialTopo.Global_Init_Topo(SPC,NumNode,False)
#ListPosition = InitialTopo.Global_Init_Topo_Fix_Position(SPC,NumNode,False)
# False/ True: Nếu chọn True, toàn bộ các bước trong tạo topology mạng sẽ được giám sát và hiển thị

ListMentor = MENTOR.MenTor(ListPosition,SPC,C,W,R,0,False)
# 0: Là số giới hạn nút đầu cuối của thuật toán MENTOR. Nếu đặt bằng 0 thì không giới hạn.
# Khi một nút Backbone tìm thấy số lượng nút đầu cuối đạt của một mạng truy nhập tới giới hạn. Nó ngừng việc quét tìm nút đầu cuối. Nếu cài đặt giá trị này bằng 0 thì xem như không có giới hạn số lượng nút đầu cuối.
# False/ True: Bật tắt giám sát thuật toán

ListFinish = EsauWilliam.Esau_William(ListMentor,W_EsWi,SPC,4,False)
# False/ True: Bật tắt giám sát thuật toán
# 4: Giới hạn số nút trên cây truy nhập. Nếu đặt bằng 0 thì không giới hạn.

Node.printList2D(ListFinish)
Node.matplot_total(ListFinish,SPC)
Node.plt.grid(True, which='both', linestyle='--', linewidth=2, color='black')
Node.plt.show()





